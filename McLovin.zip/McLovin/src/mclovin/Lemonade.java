/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mclovin;

/**
 *
 * @author rigobertojuarez
 * @param <E>
 */
public interface Lemonade <E extends Comparable<E>>
{
    public void insert (String item);
    public Node<E> find (String item);
    public void modify (E item);
    public void delete (String item);
    public void printInOrder();//use from old program

}
