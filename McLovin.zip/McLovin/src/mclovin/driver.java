/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mclovin;

/**
 *
 * @author rigobertojuarez
 */
public class driver {


    public static void main(String[] args) {
        // Create Splay Tree
        AVL<String> s = new AVL<String>();
        // Insert items into tree
        s.insert("Zebra");
        s.insert("Banana");
        s.insert("Market");
        s.insert("Cobra");
        s.insert("Apple");

        // Inorder Traversal
        System.out.println("Inorder Traversal:");
        s.printInOrder();
        System.out.println();

        // Print Reverse Order and Height
        System.out.println("Reverse Order and Height:");
        //s.printReverseOrderAndHeight();
        System.out.println();

        // Print First Three Levels of Tree
        System.out.println("First Three Levels of Tree:");
        //s.printThreeLevels();
        System.out.println();

        // Find an item in tree
        System.out.println("Search Tree for:");
        System.out.println(s.find("Banana").getData());
        //new Node <string> test = s.find("Banana");
        //System.out.println(s.find("Apple"));
        System.out.println("Now the splay tree looks like:");
        //s.printByLevels();
    }
}

