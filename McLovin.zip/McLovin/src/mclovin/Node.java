/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mclovin;

/**
 *
 * @author rigobertojuarez
 * @param <E>
 */
public class Node <E extends Comparable<E>> implements Comparable<Node>
{
    private String barcode;
    private double weight, volumeLength, volumeHeight, volumewidth;
    private int initialQuantity, unitsAvialable;
    private Node<E> left, right, parent;
    public Node()
    {
        //default constructor
        //New object created with null
        this.barcode=null;
        this.weight=-1;
        this.volumeLength=-1;
        this.volumeHeight=-1;
        this.volumewidth=-1;
        this.initialQuantity=-1;
        this.unitsAvialable=-1;
        this.left=null;
        this.right=null;
        this.parent=null;
    }
    public Node(String newBarcode)
    {
        //default constructor
        //New object created with null
        this.barcode=newBarcode;
        this.weight=-1;
        this.volumeLength=-1;
        this.volumeHeight=-1;
        this.volumewidth=-1;
        this.initialQuantity=-1;
        this.unitsAvialable=-1;
        this.left=null;
        this.right=null;
        this.parent=null;
    }
    public Node(String newBarcode, Node<E> Parent)
    {
        //default constructor
        //New object created with null
        this.barcode=newBarcode;
        this.weight=-1;
        this.volumeLength=-1;
        this.volumeHeight=-1;
        this.volumewidth=-1;
        this.initialQuantity=-1;
        this.unitsAvialable=-1;
        this.left=null;
        this.right=null;
        this.parent=Parent;
    }


    public String getData()
    {
        return this.barcode;
    }
    public void setData(String newvalue)
    {
        this.barcode=newvalue;
    }

    public void setInitialQuantity(int newInitialQuantity)
    {
        this.initialQuantity=newInitialQuantity;
    }
    public int getInitialQuantity()
    {
        return this.initialQuantity;
    }

    //get and set for BARCODE
    public void setBarcode(String newValue)
    {
        this.barcode=newValue;
    }


    //get and set for VOLUMELENGTH
    public void setVolumeLength(double newValue)
    {
        this.volumeLength=newValue;
    }
    public double getVolumeLength()
    {
        return this.volumeLength;
    }

    //get and set for WEIGHT
    public void setWeight(double newValue)
    {
        this.weight=newValue;
    }
    public double getWeight()
    {
        return this.weight;
    }

    //get and set for VOLUMEWIDTH
    public void setVolumewidth(double newValue)
    {
        this.volumewidth=newValue;
    }
    public double getVolumewidth()
    {
        return this.volumewidth;
    }

    //get and set for VOLUMEHEIGHT
    public void setVolumeHeight(double newValue)
    {
        this.volumeHeight=newValue;
    }
    public double getVolumeHeight()
    {
        return this.volumeHeight;
    }

    //get and set for UNITS AVAILABLE
    public void setUnitsAvialable(int newValue)
    {
        this.unitsAvialable=newValue;
    }
    public double getUnitsAvialable()
    {
        return this.unitsAvialable;
    }

    //get and set for LEFT
    public void setLeft(Node<E> newValue)
    {
        this.left=newValue;
    }
    public Node<E> getLeft()
    {
        return this.left;
    }

    //get and set for RIGHT
    public void setRight(Node<E> newValue)
    {
        this.right=newValue;
    }
    public Node<E> getRight()
    {
        return this.right;
    }

    //get and set for PARENT
    public void setParent(Node<E> newValue)
    {
        this.parent=newValue;
    }
    public Node<E> getParent()
    {
        return this.parent;
    }

    public int compareTo(Node b){
        if(b.barcode.compareTo(this.getData()) < 0) return 1;
        if(b.barcode.compareTo(this.getData()) > 0) return -1;
        else                   return 0;
    }
}
