/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mahek
 */
import java.sql.*;
import javax.swing.*;


public class javaconnect {
    
    Connection conn=null;
    
    public static Connection ConnecrDb(){
        
        try {
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lemons?useSSL=false");
        JOptionPane.showMessageDialog(null, "Connection established");
	return conn;
					
	} catch (Exception e) 
	{
	JOptionPane.showMessageDialog(null, e);
        return null;
	}
    }
    
}
/*import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.DbUtils;


public class Profit_Loss extends javax.swing.JFrame {
    
    Connection conn=null;
    ResultSet rs=null;
    PreparedStatement pst=null;

    /**
     * Creates new form Profit_Loss
     */
  /*  public Profit_Loss() {
        initComponents();
        conn=javaconnect.ConnecrDb();
        Update_table();
    }
    private void Update_table(){
        try{
        String sql = "select * from inventory";
        pst=conn.prepareStatement(sql);
        rs=pst.executeQuery();
        inventory_revenue.setModel(DbUtils.resultSetToTableModel(rs));
    }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
*/