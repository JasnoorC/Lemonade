import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Inventory extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inventory frame = new Inventory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inventory() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 1250, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton backButton = new JButton("Back");
		backButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenu window = new MainMenu();
				window.frame.setVisible(true);
				dispose();
			}
		});
		backButton.setBounds(21, 21, 91, 28);
		contentPane.add(backButton);
		
		JButton button = new JButton("Logout");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		button.setBounds(1095, 18, 108, 28);
		contentPane.add(button);
		
		JButton customerButton = new JButton("Customer Info");
		customerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				CustomerInf customer = new CustomerInf();
				customer.setVisible(true);
			}
		});
		customerButton.setBounds(21, 100, 247, 35);
		contentPane.add(customerButton);
		
		JButton pinfoButton = new JButton("Product Info");
		pinfoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				ProductInfo product = new ProductInfo();
				product.setVisible(true);
			}
		});
		pinfoButton.setBounds(21, 184, 247, 35);
		contentPane.add(pinfoButton);
		
		JButton oinfoButton = new JButton("Order Info");
		oinfoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				OrderInfo order = new OrderInfo();
				order.setVisible(true);
			}
			
		});
		oinfoButton.setBounds(21, 268, 247, 35);
		contentPane.add(oinfoButton);
	}
}
