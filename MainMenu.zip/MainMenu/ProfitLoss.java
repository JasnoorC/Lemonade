package MainMenu;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

//import net.proteanit.sql.DbUtils;

public class ProfitLoss extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JTable table_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JTextField textFieldNum1;
	private JTextField textFieldNum2;
	private JTextField textFieldAns;
	private JButton resetButton;
	private JButton btnBackButton;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfitLoss frame = new ProfitLoss();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProfitLoss() {

                jLabel1 = new javax.swing.JLabel();
                
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50, 50, 1250, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_1.setBounds(1106, 21, 97, 24);
		contentPane.add(btnNewButton_1);

		table = new JTable();
		table.setBounds(67, 257, 318, -168);
		contentPane.add(table);

		//**********************************************Inventory & Revenue Table************************************************
		
		btnNewButton = new JButton("Inventory & Revenue");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					/*Class.forName("com.mysql.jdbc.Driver");
					
					Connection conn = DriverManager.getConnection(
							"jdbc:mysql://localhost:3306/lemons?allowPublicKeyRetrieval=true&useSSL=false", "lemons",
							"password");

					Statement stmt = (Statement) conn.createStatement();
					String sql = "select productid, name, stock_quantity, product_price, sales_price from product ";
					ResultSet rs = stmt.executeQuery(sql);
					
					table_1.setModel(DbUtils.resultSetToTableModel(rs));*/

				} catch (Exception e2) {
					
					System.out.println(e2);
				}

			}
		});

		btnNewButton.setBounds(31, 66, 671, 35);
		contentPane.add(btnNewButton);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 122, 671, 407);
		contentPane.add(scrollPane);

		table_1 = new JTable();
		scrollPane.setViewportView(table_1);

		btnNewButton_2 = new JButton("Total Sales Revenue");
		btnNewButton_2.setBounds(731, 144, 221, 35);
		contentPane.add(btnNewButton_2);

		btnNewButton_3 = new JButton("Total Cost");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(731, 200, 221, 35);
		contentPane.add(btnNewButton_3);

		btnNewButton_4 = new JButton("Net Profit");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1, num2, ans;

				try {
					num1 = Integer.parseInt(textFieldNum1.getText());
					num2 = Integer.parseInt(textFieldNum2.getText());

					ans = num1 - num2;
					textFieldAns.setText(Integer.toString(ans));
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "Please enter valid number");
				}
			}
		});
		btnNewButton_4.setBounds(731, 274, 221, 35);
		contentPane.add(btnNewButton_4);

		textFieldNum1 = new JTextField();
		textFieldNum1.setBounds(998, 145, 186, 32);
		contentPane.add(textFieldNum1);
		textFieldNum1.setColumns(10);

		textFieldNum2 = new JTextField();
		textFieldNum2.setBounds(998, 201, 186, 32);
		contentPane.add(textFieldNum2);
		textFieldNum2.setColumns(10);

		textFieldAns = new JTextField();
		textFieldAns.setBounds(998, 277, 186, 32);
		contentPane.add(textFieldAns);
		textFieldAns.setColumns(10);

		resetButton = new JButton("Reset");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldNum1.setText("");
				textFieldNum2.setText("");
				textFieldAns.setText("");
			}
		});
		resetButton.setBounds(893, 356, 141, 35);
		contentPane.add(resetButton);

		btnBackButton = new JButton("Back");
		btnBackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenu window = new MainMenu();
				window.frame.setVisible(true);
				dispose();

			}
		});
		btnBackButton.setBounds(31, 10, 88, 24);
		contentPane.add(btnBackButton);
                
                jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("Profit Loss.png"))); // NOI18N
                getContentPane().add(jLabel1);
                jLabel1.setBounds(0, 0, 1250, 600);

	}
            private javax.swing.JLabel jLabel1;
}
